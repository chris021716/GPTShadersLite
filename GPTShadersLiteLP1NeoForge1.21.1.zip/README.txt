GPT Shaders Lite Prototype 1

Welcome to Lite Prototype 1

LP1 is the first prototype of GPT Shaders Lite.

This build is focused on very high FPS while still improving the look of Minecraft.

What's Included

- Lightweight water animation.
- Simple blue water tint.
- Warm torch and lava lighting.
- Simple waving foliage.
- Slight color enhancement.
- Performance-focused rendering.

Not Included

- No custom sky.
- No Fresnel water reflections.
- No advanced fog.
- No bloom.
- No heavy lighting effects.

Target Hardware

- Intel UHD Graphics
- Intel Iris Xe Graphics
- AMD Radeon Vega Graphics
- NVIDIA GeForce GTX 750 Ti
- NVIDIA GeForce GTX 950
- NVIDIA GeForce GTX 1050 / 1050 Ti
- NVIDIA GeForce GTX 1650
- AMD Radeon RX 460
- AMD Radeon RX 560

Target Performance

GPT Shaders Lite is designed for very high FPS.
Target range: around 300 to 350 FPS on stronger systems, depending on settings.

Installation

1. Put the ZIP into your .minecraft/shaderpacks folder.
2. Open Minecraft with Iris Shaders.
3. Select GPT Shaders Lite LP1.

If you think this is going to be like BSL, then look somewhere else.

Created by Chris with development assistance from ChatGPT.
