#version 120

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;

uniform sampler2D texture;
uniform sampler2D lightmap;

void main() {
    vec4 texColor = texture2D(texture, texcoord) * color;
    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb;

    // Simple clean blue tint, no Fresnel, no reflections.
    vec3 waterTint = vec3(0.08, 0.36, 0.62);
    texColor.rgb = mix(texColor.rgb, waterTint, 0.45);
    texColor.a *= 0.78;

    float torch = lmcoord.x;
    vec3 warmGlow = vec3(0.85, 0.38, 0.10) * (torch * torch);

    gl_FragColor = vec4(texColor.rgb * (lightmapColor + warmGlow), texColor.a);
}
