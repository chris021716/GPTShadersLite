#version 120

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;

uniform float frameTimeCounter;
uniform mat4 gbufferModelViewInverse;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
    color = gl_Color;

    vec4 pos = gl_Vertex;
    vec4 worldPos = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;

    // One sine wave only. Lite means Lite.
    float wave = sin(frameTimeCounter * 0.85 + worldPos.x * 0.35 + worldPos.z * 0.35) * 0.025;
    pos.y += wave;

    gl_Position = gl_ProjectionMatrix * gl_ModelViewMatrix * pos;
}
