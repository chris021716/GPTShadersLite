#version 120

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying float dist;

uniform float frameTimeCounter;
uniform mat4 gbufferModelViewInverse;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
    color = gl_Color;

    vec4 pos = gl_Vertex;
    vec4 worldPos = gbufferModelViewInverse * gl_ModelViewMatrix * gl_Vertex;

    // Very cheap foliage detection.
    bool isFoliage = color.g > color.r * 1.08 && color.g > color.b * 1.02 && color.g > 0.20;

    if (isFoliage) {
        float t = frameTimeCounter;
        float wave = sin(t * 0.95 + worldPos.x * 0.55 + worldPos.z * 0.45) * 0.035;

        // Move only the upper part of crossed-quad plants/leaves.
        float topMask = smoothstep(0.45, 0.95, gl_MultiTexCoord0.t);
        pos.x += wave * topMask;
    }

    vec4 viewPosition = gl_ModelViewMatrix * pos;
    dist = length(viewPosition.xyz);

    gl_Position = gl_ProjectionMatrix * viewPosition;
}
