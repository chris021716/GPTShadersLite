#version 120

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying float dist;

uniform sampler2D texture;
uniform sampler2D lightmap;

void main() {
    vec4 texColor = texture2D(texture, texcoord) * color;
    if (texColor.a < 0.1) discard;

    vec3 lightmapColor = texture2D(lightmap, lmcoord).rgb;

    float torch = lmcoord.x;
    float sky = lmcoord.y;

    // Cheap warm torch/lava glow.
    vec3 warmGlow = vec3(1.05, 0.48, 0.12) * (torch * torch);

    // Tiny sky boost so daylight feels less flat.
    vec3 skyBoost = vec3(0.045, 0.055, 0.070) * sky;

    vec3 finalColor = texColor.rgb * (lightmapColor + warmGlow + skyBoost);

    // Very cheap color polish.
    float luma = dot(finalColor, vec3(0.299, 0.587, 0.114));
    finalColor = mix(vec3(luma), finalColor, 1.06);

    gl_FragColor = vec4(finalColor, texColor.a);
}
